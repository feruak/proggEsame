﻿namespace proggEsame.Models
{
    public class LocaliModel
    {
        public string CodLocale { get; set; }
        public string Nome { get; set; }
        public string Luogo { get; set; }
        public int Posti { get; set; }
    }
}
