﻿namespace proggEsame.Models
{
    public class EventiModel
    {
        public string NomeEvento { get; set; }

        public string NomeLocale { get; set; }

        public string Luogo { get; set; }
        public int Posti { get; set; }
    }
}
