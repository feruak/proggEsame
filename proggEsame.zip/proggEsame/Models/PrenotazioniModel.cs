﻿namespace proggEsame.Models
{
    public class PrenotazioniModel
    {
        public string CodUtente { get; set; }
        public string CodReplica { get; set; }
        public int Quantita { get; set; }
    }
}
