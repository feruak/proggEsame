﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using proggEsame.DB;
using proggEsame.DB.Entities;
using proggEsame.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace proggEsame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrenotazioniController : ControllerBase
    {
        private readonly Repository repository;
        public PrenotazioniController(Repository repository)
        {
            this.repository = repository;
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] PrenotazioniModel model)
        {
            Prenotazioni p = new Prenotazioni();
            
            p.CodUtente = User.Identity.Name;
            p.Quantita = model.Quantita;
            p.CodReplica = model.CodReplica;

            this.repository.InsertPrenotazioni(p);
            return Ok();
        }
    }
}
