﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using proggEsame.DB;
using proggEsame.DB.Entities;
using proggEsame.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace proggEsame.Controllers
{
    public class HomeController : Controller
    {
        private readonly Repository repository;
        private SignInManager<User> signInManager;
        private UserManager<User> userManager;
        private UserDBContext dbContext;
        public HomeController(SignInManager<User> signInManager,
            UserManager<User> userManager,
            UserDBContext dbContext,
            Repository repository)
        {
            this.signInManager = signInManager;
            this.userManager = userManager;
            this.dbContext = dbContext;
            this.repository = repository;
        }

        public IActionResult Index()
        {
            List<Eventi> eventi = this.repository.GetEventi();
            List<EventiModel> model = new List<EventiModel>();
            foreach (Eventi e in eventi)
            {
                List<Locali> locali = this.repository.GetLocaleByID(e.CodLocale);
                foreach (Locali local in locali)
                {
                    model.Add(new EventiModel()
                    {
                        NomeEvento = e.NomeEvento,
                        Luogo = local.Luogo,
                        NomeLocale = local.Nome,
                        Posti = local.Posti,
                    });

                }
            }
            return View(model);
        }
        [Authorize]
        public IActionResult Prenota()
        {
            List<Repliche> repliche = this.repository.GetRepliche();

            List<ReplicheModel> model = new List<ReplicheModel>();
            foreach (Repliche r in repliche)
            {
                List<Eventi> eventi = this.repository.GetEventiByID(r.CodEvento);
                foreach (Eventi e in eventi)
                {
                    List<Locali> locali = this.repository.GetLocaleByID(e.CodLocale);
                    foreach (Locali local in locali)
                    {
                        model.Add(new ReplicheModel()
                        {
                            CodReplica = r.CodReplica,
                            NomeEvento = e.NomeEvento,
                            Luogo = local.Luogo,
                            NomeLocale = local.Nome,
                            Posti = local.Posti,
                            DataEOra = r.DataEOra,
                            Annullato = r.Annullato,
                        });
                    }


                }
            }
            return View(model);
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginModel loginModel)
        {
            try
            {
                User user = await userManager.FindByNameAsync(loginModel.UserName);
                if (user != null)
                {
                    var result = await signInManager.PasswordSignInAsync(loginModel.UserName, loginModel.Password, false, lockoutOnFailure: true);
                    if (result.Succeeded)
                    {

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return Redirect("Index");
        }

        [Authorize]
        public async Task<IActionResult> Logout()
        {
            try
            {
                if (signInManager.IsSignedIn(User))
                {
                    await signInManager.SignOutAsync();
                }
            }
            catch (Exception ex)
            {
            }
            return Redirect("Index");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
