USE [master]
GO
/****** Object:  Database [CrocieraDB]    Script Date: 20/07/2022 18:46:21 ******/
CREATE DATABASE [CrocieraDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'CrocieraDB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS01\MSSQL\DATA\CrocieraDB.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'CrocieraDB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS01\MSSQL\DATA\CrocieraDB_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [CrocieraDB] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [CrocieraDB].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [CrocieraDB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [CrocieraDB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [CrocieraDB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [CrocieraDB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [CrocieraDB] SET ARITHABORT OFF 
GO
ALTER DATABASE [CrocieraDB] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [CrocieraDB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [CrocieraDB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [CrocieraDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [CrocieraDB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [CrocieraDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [CrocieraDB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [CrocieraDB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [CrocieraDB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [CrocieraDB] SET  DISABLE_BROKER 
GO
ALTER DATABASE [CrocieraDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [CrocieraDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [CrocieraDB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [CrocieraDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [CrocieraDB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [CrocieraDB] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [CrocieraDB] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [CrocieraDB] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [CrocieraDB] SET  MULTI_USER 
GO
ALTER DATABASE [CrocieraDB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [CrocieraDB] SET DB_CHAINING OFF 
GO
ALTER DATABASE [CrocieraDB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [CrocieraDB] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [CrocieraDB] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [CrocieraDB] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [CrocieraDB] SET QUERY_STORE = OFF
GO
USE [CrocieraDB]
GO
/****** Object:  Table [dbo].[AspNetRoleClaims]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetRoleClaims](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ClaimType] [nvarchar](max) NULL,
	[ClaimValue] [nvarchar](max) NULL,
	[RoleId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AspNetRoleClaims] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetRoles]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetRoles](
	[Id] [nvarchar](450) NOT NULL,
	[ConcurrencyStamp] [nvarchar](max) NULL,
	[Name] [nvarchar](256) NULL,
	[NormalizedName] [nvarchar](256) NULL,
 CONSTRAINT [PK_AspNetRoles] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUserClaims]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserClaims](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ClaimType] [nvarchar](max) NULL,
	[ClaimValue] [nvarchar](max) NULL,
	[UserId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AspNetUserClaims] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUserLogins]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserLogins](
	[LoginProvider] [nvarchar](450) NOT NULL,
	[ProviderKey] [nvarchar](450) NOT NULL,
	[ProviderDisplayName] [nvarchar](max) NULL,
	[UserId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AspNetUserLogins] PRIMARY KEY CLUSTERED 
(
	[LoginProvider] ASC,
	[ProviderKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUserRoles]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserRoles](
	[UserId] [nvarchar](450) NOT NULL,
	[RoleId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AspNetUserRoles] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUsers]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUsers](
	[Id] [nvarchar](450) NOT NULL,
	[AccessFailedCount] [int] NOT NULL,
	[ConcurrencyStamp] [nvarchar](max) NULL,
	[Email] [nvarchar](256) NULL,
	[EmailConfirmed] [bit] NOT NULL,
	[LockoutEnabled] [bit] NOT NULL,
	[LockoutEnd] [datetimeoffset](7) NULL,
	[NormalizedEmail] [nvarchar](256) NULL,
	[NormalizedUserName] [nvarchar](256) NULL,
	[PasswordHash] [nvarchar](max) NULL,
	[PhoneNumber] [nvarchar](max) NULL,
	[PhoneNumberConfirmed] [bit] NOT NULL,
	[SecurityStamp] [nvarchar](max) NULL,
	[TwoFactorEnabled] [bit] NOT NULL,
	[UserName] [nvarchar](256) NULL,
	[FirstName] [nvarchar](max) NULL,
	[LastName] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetUsers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUserTokens]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserTokens](
	[UserId] [nvarchar](450) NOT NULL,
	[LoginProvider] [nvarchar](450) NOT NULL,
	[Name] [nvarchar](450) NOT NULL,
	[Value] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetUserTokens] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[LoginProvider] ASC,
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Eventi]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Eventi](
	[CodEvento] [varchar](4) NOT NULL,
	[CodLocale] [varchar](4) NULL,
	[NomeEvento] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[CodEvento] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Locali]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Locali](
	[CodLocale] [varchar](4) NOT NULL,
	[Nome] [varchar](50) NULL,
	[Luogo] [varchar](100) NULL,
	[Posti] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[CodLocale] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Prenotazioni]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Prenotazioni](
	[CodPrenotazione] [varchar](4) NOT NULL,
	[CodUtente] [nvarchar](450) NULL,
	[CodReplica] [varchar](4) NULL,
	[Quantita] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[CodPrenotazione] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Repliche]    Script Date: 20/07/2022 18:46:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Repliche](
	[CodReplica] [varchar](4) NOT NULL,
	[CodeEvento] [varchar](4) NULL,
	[DataEOra] [date] NULL,
	[Annullato] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[CodReplica] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[AspNetRoles] ([Id], [ConcurrencyStamp], [Name], [NormalizedName]) VALUES (N'b5dad443-fd55-408a-8039-771d684dffd3', N'52ea3c72-81db-43fe-9f18-a2c0fadc22b8', N'Admin', N'ADMIN')
GO
INSERT [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'07ead05e-6ce7-4dd5-adc6-2360392928fe', N'b5dad443-fd55-408a-8039-771d684dffd3')
GO
INSERT [dbo].[AspNetUsers] ([Id], [AccessFailedCount], [ConcurrencyStamp], [Email], [EmailConfirmed], [LockoutEnabled], [LockoutEnd], [NormalizedEmail], [NormalizedUserName], [PasswordHash], [PhoneNumber], [PhoneNumberConfirmed], [SecurityStamp], [TwoFactorEnabled], [UserName], [FirstName], [LastName]) VALUES (N'07ead05e-6ce7-4dd5-adc6-2360392928fe', 0, N'eff9cfdf-253c-4f98-a272-6b5ccc5dcd4a', N'admin@admin.it', 0, 1, NULL, N'ADMIN@ADMIN.IT', N'ADMIN@ADMIN.IT', N'AQAAAAEAACcQAAAAEDJgc519+N8b4EA82qZ8qhSKFnipgc4oz6FJraoBs4PrUPe5BfVHZtOQwtE+9Gjd3g==', NULL, 0, N'AB47ZNRBRBBLEFXJMESBDADC5O4AZF5J', 0, N'Admin', NULL, NULL)
GO
INSERT [dbo].[AspNetUsers] ([Id], [AccessFailedCount], [ConcurrencyStamp], [Email], [EmailConfirmed], [LockoutEnabled], [LockoutEnd], [NormalizedEmail], [NormalizedUserName], [PasswordHash], [PhoneNumber], [PhoneNumberConfirmed], [SecurityStamp], [TwoFactorEnabled], [UserName], [FirstName], [LastName]) VALUES (N'22dbf2b6-d310-4910-9815-5985f4b99094', 0, N'8926973e-95ec-4f8a-9615-a1886296d7b2', N'sic89@tel.com', 0, 1, NULL, N'SIC89@TEL.COM', N'SIC89@TEL.COM', N'AQAAAAEAACcQAAAAEN+u8pbAiV93aede9ro9dGlDwu1y4cc/eCi4eOZau8YjN1tk2+ho/HNJDa205V281w==', N'3389988555', 1, N'UNLQG3SWYHQV6ZZIDZEFXDNIUTQCVM4S', 0, N'sic89@tel.com', N'Elena', N'Siciliano')
GO
INSERT [dbo].[AspNetUsers] ([Id], [AccessFailedCount], [ConcurrencyStamp], [Email], [EmailConfirmed], [LockoutEnabled], [LockoutEnd], [NormalizedEmail], [NormalizedUserName], [PasswordHash], [PhoneNumber], [PhoneNumberConfirmed], [SecurityStamp], [TwoFactorEnabled], [UserName], [FirstName], [LastName]) VALUES (N'6d1ff15e-dee6-408e-8309-f2954fa748d1', 0, N'c346c027-2a0c-4521-aaa0-7278ff5dcea4', N'casi.anto@mail.com', 0, 1, NULL, N'CASI.ANTO@MAIL.COM', N'CASI.ANTO@MAIL.COM', N'AQAAAAEAACcQAAAAEPJsZyLK4KqnxXKUfoVA0VSQCwUnFeVXlyRAehaY6bUsJWNuC1630509OIcE3QnhmQ==', N'3351122333', 1, N'MNSRH3ERTYTZHGCGUONFITBG5IP2ZKYR', 0, N'casi.anto@mail.com', N'Antonio', N'Cassini')
GO
INSERT [dbo].[AspNetUsers] ([Id], [AccessFailedCount], [ConcurrencyStamp], [Email], [EmailConfirmed], [LockoutEnabled], [LockoutEnd], [NormalizedEmail], [NormalizedUserName], [PasswordHash], [PhoneNumber], [PhoneNumberConfirmed], [SecurityStamp], [TwoFactorEnabled], [UserName], [FirstName], [LastName]) VALUES (N'96f5ffe4-cc20-472c-af2e-18b29cef29a4', 0, N'9bc417ba-667a-49a5-97ad-fb12b6d8962c', N'for.enrico@mail.com', 0, 1, NULL, N'FOR.ENRICO@MAIL.COM', N'FOR.ENRICO@MAIL.COM', N'AQAAAAEAACcQAAAAENzDgFknbjWDWTWQlMeVv9YfLGoiYIF+TMQoXdjgLRkrCkEFijzjtEet9kGcD+9F3w==', N'3335566223', 1, N'GW3OAPMTWALO7K33MM7CF65ZCHW4MVNQ', 0, N'for.enrico@mail.com', N'Enrico', N'Fornari')
GO
INSERT [dbo].[AspNetUsers] ([Id], [AccessFailedCount], [ConcurrencyStamp], [Email], [EmailConfirmed], [LockoutEnabled], [LockoutEnd], [NormalizedEmail], [NormalizedUserName], [PasswordHash], [PhoneNumber], [PhoneNumberConfirmed], [SecurityStamp], [TwoFactorEnabled], [UserName], [FirstName], [LastName]) VALUES (N'f357946a-e1dc-45ee-8c63-9b4e8bd55cd3', 0, N'840c1786-037a-4f3c-bc61-806921c72feb', N'b.bianca@usrmail.it', 0, 1, NULL, N'B.BIANCA@USRMAIL.IT', N'B.BIANCA@USRMAIL.IT', N'AQAAAAEAACcQAAAAEKGhMaEJsNyTe0EVYG4YoIIwWrSiX7hA2AH0gMONcMGM5fLjl/LEGg7cRkRe7zNY6Q==', N'3384455666', 1, N'YFRMXC2VMFSDAAJXIB6MLXZUWUCYNYH5', 0, N'b.bianca@usrmail.it', N'Bianca', N'Benedetti')
GO
INSERT [dbo].[Eventi] ([CodEvento], [CodLocale], [NomeEvento]) VALUES (N'0001', N'0001', N'Concerto di Chopin')
GO
INSERT [dbo].[Eventi] ([CodEvento], [CodLocale], [NomeEvento]) VALUES (N'0002', N'0001', N'Beethoven sul mare')
GO
INSERT [dbo].[Eventi] ([CodEvento], [CodLocale], [NomeEvento]) VALUES (N'0003', N'0002', N'Il ventaglio - Goldoni')
GO
INSERT [dbo].[Eventi] ([CodEvento], [CodLocale], [NomeEvento]) VALUES (N'0004', N'0004', N'Pool Brunch Party')
GO
INSERT [dbo].[Locali] ([CodLocale], [Nome], [Luogo], [Posti]) VALUES (N'0001', N'Music Lounge', N'Ponte3-Piano2', 150)
GO
INSERT [dbo].[Locali] ([CodLocale], [Nome], [Luogo], [Posti]) VALUES (N'0002', N'Teatro', N'Ponte8-Piano3', 350)
GO
INSERT [dbo].[Locali] ([CodLocale], [Nome], [Luogo], [Posti]) VALUES (N'0003', N'Casinò', N'Ponte7-Piano4', 450)
GO
INSERT [dbo].[Locali] ([CodLocale], [Nome], [Luogo], [Posti]) VALUES (N'0004', N'Piscina', N'Ponte5-Piano9', 150)
GO
INSERT [dbo].[Prenotazioni] ([CodPrenotazione], [CodUtente], [CodReplica], [Quantita]) VALUES (N'0001', N'6d1ff15e-dee6-408e-8309-f2954fa748d1', N'0002', 2)
GO
INSERT [dbo].[Prenotazioni] ([CodPrenotazione], [CodUtente], [CodReplica], [Quantita]) VALUES (N'0002', N'f357946a-e1dc-45ee-8c63-9b4e8bd55cd3', N'0002', 5)
GO
INSERT [dbo].[Prenotazioni] ([CodPrenotazione], [CodUtente], [CodReplica], [Quantita]) VALUES (N'0003', N'6d1ff15e-dee6-408e-8309-f2954fa748d1', N'0004', 2)
GO
INSERT [dbo].[Prenotazioni] ([CodPrenotazione], [CodUtente], [CodReplica], [Quantita]) VALUES (N'0004', N'96f5ffe4-cc20-472c-af2e-18b29cef29a4', N'0004', 2)
GO
INSERT [dbo].[Repliche] ([CodReplica], [CodeEvento], [DataEOra], [Annullato]) VALUES (N'0001', N'0001', CAST(N'2020-07-27' AS Date), 0)
GO
INSERT [dbo].[Repliche] ([CodReplica], [CodeEvento], [DataEOra], [Annullato]) VALUES (N'0002', N'0001', CAST(N'2020-07-28' AS Date), 0)
GO
INSERT [dbo].[Repliche] ([CodReplica], [CodeEvento], [DataEOra], [Annullato]) VALUES (N'0003', N'0001', CAST(N'2020-07-29' AS Date), 0)
GO
INSERT [dbo].[Repliche] ([CodReplica], [CodeEvento], [DataEOra], [Annullato]) VALUES (N'0004', N'0002', CAST(N'2020-08-01' AS Date), 0)
GO
INSERT [dbo].[Repliche] ([CodReplica], [CodeEvento], [DataEOra], [Annullato]) VALUES (N'0005', N'0003', CAST(N'2020-07-30' AS Date), 0)
GO
INSERT [dbo].[Repliche] ([CodReplica], [CodeEvento], [DataEOra], [Annullato]) VALUES (N'0006', N'0004', CAST(N'2020-07-27' AS Date), 1)
GO
ALTER TABLE [dbo].[AspNetRoleClaims]  WITH CHECK ADD  CONSTRAINT [FK_AspNetRoleClaims_AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetRoleClaims] CHECK CONSTRAINT [FK_AspNetRoleClaims_AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[AspNetUserClaims]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserClaims_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserClaims] CHECK CONSTRAINT [FK_AspNetUserClaims_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserLogins]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserLogins_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserLogins] CHECK CONSTRAINT [FK_AspNetUserLogins_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserRoles_AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_AspNetUserRoles_AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserRoles_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_AspNetUserRoles_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[Eventi]  WITH CHECK ADD FOREIGN KEY([CodLocale])
REFERENCES [dbo].[Locali] ([CodLocale])
GO
ALTER TABLE [dbo].[Prenotazioni]  WITH CHECK ADD FOREIGN KEY([CodReplica])
REFERENCES [dbo].[Repliche] ([CodReplica])
GO
ALTER TABLE [dbo].[Prenotazioni]  WITH CHECK ADD FOREIGN KEY([CodUtente])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[Repliche]  WITH CHECK ADD FOREIGN KEY([CodeEvento])
REFERENCES [dbo].[Eventi] ([CodEvento])
GO
USE [master]
GO
ALTER DATABASE [CrocieraDB] SET  READ_WRITE 
GO
