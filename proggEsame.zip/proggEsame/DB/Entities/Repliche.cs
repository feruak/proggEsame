﻿using System;
using System.ComponentModel.DataAnnotations;

namespace proggEsame.DB.Entities
{
    public class Repliche
    {
        [Key]
        public string CodReplica { get; set; }
        public string CodEvento { get; set; }
        public DateTime DataEOra { get; set; }
        public bool Annullato { get; set; }
    }
}
