﻿using Microsoft.AspNetCore.Identity;

namespace proggEsame.DB.Entities
{
    public class User : IdentityUser
    {
    }
}
