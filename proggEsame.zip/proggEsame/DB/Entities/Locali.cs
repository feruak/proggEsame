﻿using System;
using System.ComponentModel.DataAnnotations;

namespace proggEsame.DB.Entities
{
    public class Locali
    {
        [Key]
        public string CodLocale { get; set; }
        public string Nome { get; set; }
        public string Luogo { get; set; }
        public int Posti { get; set; }

    }
}
