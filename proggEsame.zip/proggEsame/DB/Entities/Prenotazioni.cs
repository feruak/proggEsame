﻿using System;
using System.ComponentModel.DataAnnotations;

namespace proggEsame.DB.Entities
{
    public class Prenotazioni
    {
        [Key]
        public string CodPrenotazione { get; set; }
        public string CodUtente { get; set; }
        public string CodReplica { get; set; }
        public int Quantita { get; set; }
    }
}
