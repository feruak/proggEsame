﻿using System;
using System.ComponentModel.DataAnnotations;

namespace proggEsame.DB.Entities
{
    public class Eventi
    {
        [Key]
        public string CodEvento { get; set; }
        public string CodLocale { get; set; }
        public string NomeEvento { get; set; }
    }
}
