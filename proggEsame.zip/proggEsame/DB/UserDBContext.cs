﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using proggEsame.DB.Entities;

namespace proggEsame.DB
{
    public class UserDBContext : IdentityDbContext<User>
    {
        public UserDBContext(DbContextOptions<UserDBContext> options)
            : base(options)
        {
        }
        public DbSet<Eventi> Eventi { get; set; }
        public DbSet<Locali> Locali { get; set; }
        public DbSet<Repliche> Repliche { get; set; }
        public DbSet<Prenotazioni> Prenotazioni { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);
        }
    }
}