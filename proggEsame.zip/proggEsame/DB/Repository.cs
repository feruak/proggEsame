﻿using System;
using System.Collections.Generic;
using System.Linq;
using proggEsame.DB.Entities;

namespace proggEsame.DB
{
    public class Repository
    {
        private UserDBContext DBContext;
        public Repository(UserDBContext DBContext)
        {
            this.DBContext = DBContext;
        }
        public List<Locali> GetLocali()
        {
            //select * from persons
            List<Locali> result = this.DBContext.Locali.ToList();
            return result;
        }
        public List<Locali> GetLocaleByID(string codLocale)
        {
            //select * from persons
            Locali locale = new Locali();
            List<Locali> locali = this.DBContext.Locali.ToList();
            locali = locali.Where(l => l.CodLocale == codLocale).ToList();
            return locali;
        }
        public List<Repliche> GetRepliche()
        {
            //select * from persons
            List<Repliche> result = this.DBContext.Repliche.ToList();
            return result;
        }
        public List<Eventi> GetEventi()
        {
            //select * from persons
            List<Eventi> result = this.DBContext.Eventi.ToList();
            return result;
        }
        public List<Eventi> GetEventiByID(string codEvento)
        {
            //select * from persons
            List<Eventi> eventi = this.DBContext.Eventi.ToList();
            eventi = eventi.Where(l => l.CodLocale == codEvento).ToList();
            return eventi;
        }
        public void InsertPrenotazioni(Prenotazioni prenotazioni)
        {
            this.DBContext.Prenotazioni.Add(prenotazioni);
            this.DBContext.SaveChanges();
            
        }
    }
}
